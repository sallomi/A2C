import networkx as nx
import osmnx as ox
import pandas as pd


#Da eseguire solo una volta, poi si salvano i dati sul file Verona.graphml quindi di possono importare per velocizzare il calcolo
'''
graph_area = ("Verona, Italy")
G = ox.graph_from_place(graph_area, network_type='walk') # definisce che ci si muove a piedi
G = ox.add_edge_speeds(G)
G = ox.add_edge_travel_times(G)
# Save graph to disk if you want to reuse it
ox.save_graphml(G, "Verona.graphml")
'''


G = ox.load_graphml("Verona.graphml") # da decommentare se si vuole caricare il grafo dal file precedentemente creato, commentare le righe prima

def getDistance(lon_dest, lat_dest, lon_origin, lat_origin):
    origin_node = ox.nearest_nodes(G, lon_origin, lat_origin)
    destination_node = ox.nearest_nodes(G, lon_dest, lat_dest)

    distance_in_meters = nx.shortest_path_length(G, origin_node, destination_node, weight='length')

    return distance_in_meters


df = pd.read_csv("poi_info.csv")
df_dist = pd.DataFrame(columns=['poi_id_1', 'poi_id_2', 'distance'])

for p1 in df.iterrows():
    for p2 in df.iterrows():
        #print(f'Processing POI {p1[1].poi_name} and POI {p2[1].poi_name}')
        if p1[1]['poi_id'] != p2[1]['poi_id']:
            filter = df_dist[(p1[1]['poi_id'] == df_dist['poi_id_1']) & (p2[1]['poi_id'] == df_dist['poi_id_2'])]
            if len(filter) == 0:
                distance = getDistance(p1[1]['longitude'], p1[1]['latitude'], p2[1]['longitude'], p2[1]['latitude'])
                df_dist = pd.concat([df_dist, pd.DataFrame({'poi_id_1': [p1[1]['poi_id']], 'poi_id_2': [p2[1]['poi_id']], 'distance': [distance]})], ignore_index=True)
            
            #print(f'Distance between POI {p1[1].poi_name} and POI {p2[1].poi_name}:  {distance} meters')


#distance = getDistance(p1['longitude'], p1['latitude'], p2['longitude'], p2['latitude'])
df_dist.to_csv("poi_distances.csv", index=False)

#print(f'Distance between POI {p1.poi_name} and POI {p2.poi_name}:  {distance} meters')